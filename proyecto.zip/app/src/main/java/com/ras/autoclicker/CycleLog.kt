package com.ras.autoclicker

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * A tiny rolling log of what the click cycle is doing.
 *
 * It exists so a failure is visible on screen instead of silent: the panel
 * shows the last few lines, which is enough to tell whether the loop is
 * running, where it is aiming, and whether Android accepted the gesture.
 */
object CycleLog {

    private const val MAX = 40
    private val lines = ArrayDeque<String>()
    private val stamp = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Volatile private var changed = false

    @Synchronized
    fun add(message: String) {
        lines.addLast("${stamp.format(Date())}  $message")
        while (lines.size > MAX) lines.removeFirst()
        changed = true
    }

    /** Last [count] lines, oldest first. */
    @Synchronized
    fun tail(count: Int): List<String> = lines.toList().takeLast(count)

    @Synchronized
    fun consumeChanged(): Boolean {
        val c = changed
        changed = false
        return c
    }

    @Synchronized
    fun clear() {
        lines.clear()
        changed = true
    }
}
