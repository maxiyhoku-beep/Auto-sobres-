package com.ras.autoclicker

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

/**
 * The floating drag handle and, in adjust mode, the pointer markers.
 *
 * Two separate things live here on purpose:
 *  - the HANDLE: one small gold disc the user drags around so the whole set
 *    can be moved without fighting the individual markers;
 *  - the MARKERS: one per active pointer, each dragged on its own.
 *
 * Everything is stored as a fraction of the screen so it survives any DPI.
 */
@SuppressLint("ViewConstructor")
class PointersView(context: Context) : View(context) {

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(2.5f)
        color = 0xFF12B76A.toInt()
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        textSize = dp(11f)
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }

    var adjusting = false
    var visiblePointers = true

    private var dragIndex = -1
    private var dragOffsetX = 0f
    private var dragOffsetY = 0f

    /** One marker on screen. x/y are fractions of the screen. */
    private data class Marker(val id: String, val tag: String, var x: Float, var y: Float)

    private fun markers(): List<Marker> {
        val p = ClickerPrefs(context)
        val list = ArrayList<Marker>()

        // Exactly ONE card-screen pointer, depending on the active mode.
        when {
            p.sellAll -> list.add(Marker("sellAll", "SELL ALL", p.sellAllX, p.sellAllY))
            p.sellMulti -> list.add(Marker("sellMulti", "SELL DUP", p.sellMultiX, p.sellMultiY))
            else -> list.add(Marker("saveAll", "SAVE ALL", p.saveAllX, p.saveAllY))
        }
        // The one that advances the pack cycle.
        list.add(Marker("nextPack", "NEXT PACK", p.nextPackX, p.nextPackY))
        // Skipping the reveal animation.
        list.add(Marker("skipAnim", "SKIP", p.skipX, p.skipY))
        // The bonus dialog, only while it is actually on screen.
        if (PanelManager.bonusMode) {
            list.add(Marker("bonusLeft", "OK", p.bonusLeftX, p.bonusY))
            list.add(Marker("bonusRight", "OK", p.bonusRightX, p.bonusY))
        }
        return list
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!adjusting && !visiblePointers) return
        if (!adjusting) return

        val w = width.toFloat()
        val h = height.toFloat()
        val r = dp(24f)

        for (m in markers()) {
            val cx = m.x * w
            val cy = m.y * h

            fill.color = 0xBBF5C542.toInt()
            canvas.drawCircle(cx, cy, r, fill)
            canvas.drawCircle(cx, cy, r, ring)

            // Crosshair: shows the exact point that will be tapped.
            canvas.drawLine(cx - r, cy, cx + r, cy, ring)
            canvas.drawLine(cx, cy - r, cx, cy + r, ring)

            canvas.drawText(m.tag, cx, cy + r + dp(13f), label)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!adjusting) return false
        val w = width.toFloat()
        val h = height.toFloat()
        val list = markers()

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                dragIndex = -1
                // Grab the nearest marker within a generous radius, and keep
                // the offset so the marker does not jump under the finger.
                var best = dp(60f)
                list.forEachIndexed { i, m ->
                    val dx = event.x - m.x * w
                    val dy = event.y - m.y * h
                    val d = kotlin.math.sqrt(dx * dx + dy * dy)
                    if (d < best) { best = d; dragIndex = i }
                }
                if (dragIndex >= 0) {
                    dragOffsetX = event.x - list[dragIndex].x * w
                    dragOffsetY = event.y - list[dragIndex].y * h
                }
                return dragIndex != -1
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragIndex == -1 || dragIndex >= list.size) return false
                val m = list[dragIndex]
                m.x = ((event.x - dragOffsetX) / w).coerceIn(0f, 1f)
                m.y = ((event.y - dragOffsetY) / h).coerceIn(0f, 1f)
                persist(m)
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragIndex = -1
                return true
            }
        }
        return false
    }

    /** Saves one position. Only the marker being moved is written. */
    private fun persist(m: Marker) {
        val p = ClickerPrefs(context)
        when (m.id) {
            "saveAll" -> { p.saveAllX = m.x; p.saveAllY = m.y }
            "sellAll" -> { p.sellAllX = m.x; p.sellAllY = m.y }
            "sellMulti" -> { p.sellMultiX = m.x; p.sellMultiY = m.y }
            "nextPack" -> { p.nextPackX = m.x; p.nextPackY = m.y }
            "skipAnim" -> { p.skipX = m.x; p.skipY = m.y }
            "bonusLeft" -> { p.bonusLeftX = m.x; p.bonusY = m.y }
            "bonusRight" -> { p.bonusRightX = m.x; p.bonusY = m.y }
        }
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density
}
