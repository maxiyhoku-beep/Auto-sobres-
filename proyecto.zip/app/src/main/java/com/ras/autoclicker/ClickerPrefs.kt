package com.ras.autoclicker

import android.content.Context

/**
 * All tunable values of the clicker in one place.
 *
 * Coordinates are stored as FRACTIONS of the screen (0.0 - 1.0) rather than
 * pixels, so the loop survives rotation, density changes and resolution
 * changes — one of the main reasons clickers freeze on Samsung devices.
 */
class ClickerPrefs(private val context: Context) {

    private val p = context.getSharedPreferences("ras_clicker", Context.MODE_PRIVATE)

    /** Writes a float and commits at once, so a drag is never lost. */
    private fun put(key: String, v: Float) {
        p.edit().putFloat(key, v).commit()
    }

    private fun put(key: String, v: Boolean) {
        p.edit().putBoolean(key, v).commit()
    }

    private fun put(key: String, v: Long) {
        p.edit().putLong(key, v).commit()
    }

    private fun put(key: String, v: Int) {
        p.edit().putInt(key, v).commit()
    }

    // ---- Modes -----------------------------------------------------------
    var sellAll: Boolean
        get() = p.getBoolean("sell_all", false)
        set(v) = put("sell_all", v)

    var sellMulti: Boolean
        get() = p.getBoolean("sell_multi", false)
        set(v) = put("sell_multi", v)

    var pointersHidden: Boolean
        get() = p.getBoolean("pointers_hidden", false)
        set(v) = put("pointers_hidden", v)

    var panelRunning: Boolean
        get() = p.getBoolean("panel_running", false)
        set(v) = put("panel_running", v)

    // ---- Timing ----------------------------------------------------------
    /** Interval between gestures, in milliseconds. */
    var intervalMs: Long
        get() = p.getLong("interval_ms", 900L)
        set(v) = put("interval_ms", v)

    /** How long the shape check waits for a button to appear, in ms. */
    var shapeTimeoutMs: Long
        get() = p.getLong("shape_timeout_ms", 4000L)
        set(v) = put("shape_timeout_ms", v)

    // ---- Anchors (fractions) --------------------------------------------
    var saveAllX: Float
        get() = p.getFloat("save_all_x", 0.62f)
        set(v) = put("save_all_x", v)
    var saveAllY: Float
        get() = p.getFloat("save_all_y", 0.924f)
        set(v) = put("save_all_y", v)

    var sellAllX: Float
        get() = p.getFloat("sell_all_x", 0.233f)
        set(v) = put("sell_all_x", v)
    var sellAllY: Float
        get() = p.getFloat("sell_all_y", 0.924f)
        set(v) = put("sell_all_y", v)

    var sellMultiX: Float
        get() = p.getFloat("sell_multi_x", 0.428f)
        set(v) = put("sell_multi_x", v)
    var sellMultiY: Float
        get() = p.getFloat("sell_multi_y", 0.924f)
        set(v) = put("sell_multi_y", v)

    var nextPackX: Float
        get() = p.getFloat("next_pack_x", 0.62f)
        set(v) = put("next_pack_x", v)
    var nextPackY: Float
        get() = p.getFloat("next_pack_y", 0.910f)
        set(v) = put("next_pack_y", v)

    /** SKIP button shown while the pack reveal animation plays. */
    var skipX: Float
        get() = p.getFloat("skip_x", 0.50f)
        set(v) = put("skip_x", v)
    var skipY: Float
        get() = p.getFloat("skip_y", 0.727f)
        set(v) = put("skip_y", v)

    /** Left and right candidates of the BONUS dialog (it swaps sides). */
    var bonusLeftX: Float
        get() = p.getFloat("bonus_left_x", 0.216f)
        set(v) = put("bonus_left_x", v)
    var bonusRightX: Float
        get() = p.getFloat("bonus_right_x", 0.71f)
        set(v) = put("bonus_right_x", v)
    var bonusY: Float
        get() = p.getFloat("bonus_y", 0.775f)
        set(v) = put("bonus_y", v)

    // ---- Session counters (reset when the clicker is turned off) ---------
    var sessionPacks: Int
        get() = p.getInt("session_packs", 0)
        set(v) = put("session_packs", v)

    var sessionStartMs: Long
        get() = p.getLong("session_start", 0L)
        set(v) = put("session_start", v)

    var accumulatedMs: Long
        get() = p.getLong("accumulated_ms", 0L)
        set(v) = put("accumulated_ms", v)

    fun resetSession() {
        sessionPacks = 0
        accumulatedMs = 0L
        sessionStartMs = 0L
    }
}
