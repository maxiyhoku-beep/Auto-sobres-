package com.ras.autoclicker

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * The floating panel, rebuilt small and tozquit-proof.
 *
 * Two modes:
 *  - RUN state  : one compact row of icon buttons (play/pause, eye, tune, close)
 *  - IDLE state : a second row appears with SELL ALL and SELL MULTI
 *
 * A separate ADJUST mode lets every pointer be dragged to its real position,
 * which is what makes the app work on any DPI or screen size.
 */
object PanelManager {

    private var container: LinearLayout? = null
    private var pointersLayer: PointersView? = null
    private var wm: WindowManager? = null

    private var rowMain: LinearLayout? = null
    private var rowModes: LinearLayout? = null
    private var counters: TextView? = null
    private var btnPlay: TextView? = null
    private var btnSellAll: TextView? = null
    private var btnSellMulti: TextView? = null
    private var btnAdjust: TextView? = null

    private var lpPanel: WindowManager.LayoutParams? = null
    private var lpPointers: WindowManager.LayoutParams? = null

    private val handler = Handler(Looper.getMainLooper())
    private var ticker: Runnable? = null

    /** True while the user is placing the pointers. */
    @Volatile var adjusting = false
        private set

    // ------------------------------------------------------------------
    // Show / hide
    // ------------------------------------------------------------------

    @SuppressLint("InflateParams")
    fun show(context: Context) {
        if (container != null) { syncState(); return }
        val ctx = LanguageManager(context).localizedContext()
        wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        // --- Pointer overlay (drawn above the game, below the panel) -----
        val pv = PointersView(ctx)
        pointersLayer = pv
        lpPointers = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        // --- Compact panel ------------------------------------------------
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xF20B0B0B.toInt())
            setPadding(dp(ctx, 10), dp(ctx, 8), dp(ctx, 10), dp(ctx, 8))
        }

        counters = TextView(ctx).apply {
            setTextColor(0xFFF5C542.toInt())
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(counters)

        // Row 1: play/pause, show/hide pointers, adjust, close.
        rowMain = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        btnPlay = icon(ctx, "\u25B6") {
            val svc = ClickerService.instance
            if (svc == null) {
                Toast.makeText(ctx, LanguageManager.string(ctx, R.string.start_service), Toast.LENGTH_SHORT).show()
            } else if (ClickerPrefs(ctx).panelRunning) {
                svc.pauseCycle(); ClickerForegroundService.stop(ctx)
            } else {
                ClickerForegroundService.start(ctx); svc.startCycle()
                PointerState.showAll()
            }
            syncState()
        }
        val btnEye = icon(ctx, "\uD83D\uDC41") {
            val p = ClickerPrefs(ctx)
            p.pointersHidden = !p.pointersHidden
            syncState()
        }
        btnAdjust = icon(ctx, "\u2699") {
            adjusting = !adjusting
            val p = ClickerPrefs(ctx)
            p.pointersHidden = false
            Toast.makeText(
                ctx,
                if (adjusting) "Arrastrá cada puntero a su botón" else "Posiciones guardadas",
                Toast.LENGTH_SHORT
            ).show()
            syncState()
        }
        val btnClose = icon(ctx, "\u2715") {
            ClickerService.instance?.stopAndReset()
            ClickerForegroundService.stop(ctx)
            hide()
        }
        rowMain?.addView(btnPlay)
        rowMain?.addView(btnEye)
        rowMain?.addView(btnAdjust)
        rowMain?.addView(btnClose)
        root.addView(rowMain)

        // Row 2: only while idle.
        rowModes = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        btnSellAll = icon(ctx, "SA") {
            val p = ClickerPrefs(ctx)
            p.sellAll = !p.sellAll
            if (p.sellAll) p.sellMulti = false
            syncState()
        }
        btnSellMulti = icon(ctx, "SM") {
            val p = ClickerPrefs(ctx)
            p.sellMulti = !p.sellMulti
            if (p.sellMulti) p.sellAll = false
            syncState()
        }
        rowModes?.addView(btnSellAll)
        rowModes?.addView(btnSellMulti)
        root.addView(rowModes)

        lpPanel = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(ctx, 12)
            y = dp(ctx, 90)
        }
        root.setOnTouchListener(DragListener(wm!!, lpPanel!!))

        try {
            wm?.addView(pv, lpPointers)
            wm?.addView(root, lpPanel)
            container = root
            syncState()
            startTicker()
        } catch (e: Exception) {
            Toast.makeText(context, "Falta el permiso de superposición", Toast.LENGTH_SHORT).show()
        }
    }

    /** One compact icon button. */
    private fun icon(ctx: Context, glyph: String, onClick: () -> Unit): TextView =
        TextView(ctx).apply {
            text = glyph
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(0xFF0B0B0B.toInt())
            setBackgroundColor(0xFFF5C542.toInt())
            val lp = LinearLayout.LayoutParams(dp(ctx, 46), dp(ctx, 46))
            lp.marginEnd = dp(ctx, 6)
            layoutParams = lp
            setOnClickListener {
                onClick()
                flash()
            }
        }

    /** Tiny press feedback so the button does not feel dead. */
    private fun TextView.flash() {
        setBackgroundColor(0xFF12B76A.toInt())
        postDelayed({ setBackgroundColor(0xFFF5C542.toInt()) }, 120)
    }

    // ------------------------------------------------------------------
    // State
    // ------------------------------------------------------------------

    @SuppressLint("SetTextI18n")
    fun syncState() {
        container?.post {
            val ctx = container?.context ?: return@post
            val p = ClickerPrefs(ctx)
            val running = p.panelRunning

            rowModes?.visibility = if (running) View.GONE else View.VISIBLE
            btnPlay?.text = if (running) "\u23F8" else "\u25B6"
            btnAdjust?.setBackgroundColor(
                if (adjusting) 0xFF12B76A.toInt() else 0xFFF5C542.toInt()
            )
            btnSellAll?.setBackgroundColor(
                if (p.sellAll) 0xFF12B76A.toInt() else 0xFFF5C542.toInt()
            )
            btnSellMulti?.setBackgroundColor(
                if (p.sellMulti) 0xFF12B76A.toInt() else 0xFFF5C542.toInt()
            )

            pointersLayer?.syncFromPrefs()
            refreshCounters()
        }
    }

    private fun startTicker() {
        stopTicker()
        ticker = object : Runnable {
            override fun run() { refreshCounters(); handler.postDelayed(this, 1000L) }
        }
        handler.postDelayed(ticker!!, 1000L)
    }

    private fun stopTicker() {
        ticker?.let { handler.removeCallbacks(it) }
        ticker = null
    }

    @SuppressLint("SetTextI18n")
    fun refreshCounters() {
        val c = container ?: return
        val ctx = c.context
        val p = ClickerPrefs(ctx)
        val elapsed = p.accumulatedMs +
            if (p.sessionStartMs != 0L) SystemClock.elapsedRealtime() - p.sessionStartMs else 0L
        val t = elapsed / 1000
        counters?.text = String.format(
            "%02d:%02d:%02d  \uD83D\uDCE6%d", t / 3600, (t % 3600) / 60, t % 60, p.sessionPacks
        )
    }

    fun hide() {
        stopTicker()
        adjusting = false
        container?.let { try { wm?.removeView(it) } catch (_: Exception) { } }
        pointersLayer?.let { try { wm?.removeView(it) } catch (_: Exception) { } }
        container = null
        pointersLayer = null
        btnPlay = null; btnSellAll = null; btnSellMulti = null; btnAdjust = null
        counters = null; rowMain = null; rowModes = null
    }

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()
}
