package com.ras.autoclicker

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * The floating panel: small, rounded, and with a live log so a failure is
 * visible on screen instead of silent.
 */
object PanelManager {

    private var container: LinearLayout? = null
    private var pointers: PointersView? = null
    private var wm: WindowManager? = null

    private var rowModes: LinearLayout? = null
    private var counters: TextView? = null
    private var logView: TextView? = null
    private var btnPlay: TextView? = null
    private var btnEye: TextView? = null
    private var btnGear: TextView? = null
    private var btnSellAll: TextView? = null
    private var btnSellMulti: TextView? = null

    private var lpPanel: WindowManager.LayoutParams? = null
    private var lpPointers: WindowManager.LayoutParams? = null

    private val handler = Handler(Looper.getMainLooper())
    private var ticker: Runnable? = null

    @Volatile var bonusMode = false
    @Volatile var adjusting = false
        private set

    private val GOLD = 0xFFF5C542.toInt()
    private val DARK = 0xF20B0B0B.toInt()
    private val GREEN = 0xFF12B76A.toInt()
    private val INK = 0xFF0B0B0B.toInt()
    private val DIM = 0xFF8A8A8A.toInt()

    // ------------------------------------------------------------------

    @SuppressLint("InflateParams")
    fun show(context: Context) {
        if (container != null) { syncState(); return }
        val ctx = LanguageManager(context).localizedContext()
        wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val type = overlayType()

        // Pointer layer, added underneath the panel buttons.
        val pv = PointersView(ctx)
        pointers = pv
        lpPointers = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(DARK, 22f, ctx)
            setPadding(dp(ctx, 9), dp(ctx, 7), dp(ctx, 9), dp(ctx, 7))
        }

        counters = TextView(ctx).apply {
            setTextColor(GOLD)
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(ctx, 2), 0, dp(ctx, 5))
        }
        root.addView(counters)

        val rowMain = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        btnPlay = pill(ctx, "\u25B6") {
            val p = ClickerPrefs(ctx)
            val svc = ClickerService.instance
            if (p.panelRunning) {
                svc?.pauseCycle()
                ClickerForegroundService.stop(ctx)
            } else if (svc == null) {
                // The service is not connected: say so and point at the fix.
                toast(ctx, ctx.getString(R.string.start_service))
                CycleLog.add("servicio no conectado")
            } else {
                ClickerForegroundService.start(ctx)
                svc.startCycle()
            }
            syncState()
        }
        btnEye = pill(ctx, "\uD83D\uDC41") {
            val p = ClickerPrefs(ctx)
            p.pointersHidden = !p.pointersHidden
            syncState()
        }
        btnGear = pill(ctx, "\u2699") {
            adjusting = !adjusting
            ClickerPrefs(ctx).pointersHidden = false
            toast(ctx, ctx.getString(if (adjusting) R.string.adjust_hint else R.string.adjust_saved))
            syncState()
        }
        val btnClose = pill(ctx, "\u2715") {
            ClickerService.instance?.stopAndReset()
            ClickerForegroundService.stop(ctx)
            hide()
        }
        rowMain.addView(btnPlay)
        rowMain.addView(btnEye)
        rowMain.addView(btnGear)
        rowMain.addView(btnClose)
        root.addView(rowMain)

        rowModes = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(ctx, 5), 0, 0)
        }
        btnSellAll = pill(ctx, "SA", wide = true) {
            val p = ClickerPrefs(ctx)
            p.sellAll = !p.sellAll
            if (p.sellAll) p.sellMulti = false
            syncState()
        }
        btnSellMulti = pill(ctx, "SM", wide = true) {
            val p = ClickerPrefs(ctx)
            p.sellMulti = !p.sellMulti
            if (p.sellMulti) p.sellAll = false
            syncState()
        }
        rowModes?.addView(btnSellAll)
        rowModes?.addView(btnSellMulti)
        root.addView(rowModes)

        // Live log: the last few things the cycle did.
        logView = TextView(ctx).apply {
            setTextColor(DIM)
            textSize = 9f
            gravity = Gravity.START
            setPadding(dp(ctx, 4), dp(ctx, 6), dp(ctx, 4), 0)
            visibility = View.GONE
        }
        root.addView(logView)

        lpPanel = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(ctx, 14)
            y = dp(ctx, 140)
        }
        root.setOnTouchListener(DragListener(wm!!, lpPanel!!))

        try {
            wm?.addView(pv, lpPointers)
            wm?.addView(root, lpPanel)
            container = root
            syncState()
            startTicker()
        } catch (e: Exception) {
            toast(context, ctx.getString(R.string.overlay_permission))
        }
    }

    private fun pill(ctx: Context, glyph: String, wide: Boolean = false, onClick: () -> Unit): TextView =
        TextView(ctx).apply {
            text = glyph
            textSize = if (wide) 13f else 19f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(INK)
            background = rounded(GOLD, 16f, ctx)
            val w = if (wide) dp(ctx, 56) else dp(ctx, 44)
            val lp = LinearLayout.LayoutParams(w, dp(ctx, 44))
            lp.marginEnd = dp(ctx, 5)
            layoutParams = lp
            setOnClickListener { onClick() }
        }

    private fun rounded(color: Int, radiusDp: Float, ctx: Context): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusDp * ctx.resources.displayMetrics.density
            setColor(color)
            setStroke(dp(ctx, 1), 0xFFB8860B.toInt())
        }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------

    fun syncState() {
        container?.post {
            val ctx = container?.context ?: return@post
            val p = ClickerPrefs(ctx)

            rowModes?.visibility = if (p.panelRunning) View.GONE else View.VISIBLE
            btnPlay?.text = if (p.panelRunning) "\u23F8" else "\u25B6"
            btnGear?.background = rounded(if (adjusting) GREEN else GOLD, 16f, ctx)
            btnEye?.background = rounded(if (p.pointersHidden) 0xFF666666.toInt() else GOLD, 16f, ctx)
            btnSellAll?.background = rounded(if (p.sellAll) GREEN else GOLD, 16f, ctx)
            btnSellMulti?.background = rounded(if (p.sellMulti) GREEN else GOLD, 16f, ctx)

            pointers?.adjusting = adjusting
            pointers?.visiblePointers = !p.pointersHidden
            pointers?.invalidate()
            applyPointerTouchability()
            refreshCounters()
        }
    }

    /** In adjust mode the pointer layer takes touches; otherwise it does not. */
    private fun applyPointerTouchability() {
        val v = pointers ?: return
        val lp = lpPointers ?: return
        val flags = if (adjusting)
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        else
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        if (lp.flags != flags) {
            lp.flags = flags
            try { wm?.updateViewLayout(v, lp) } catch (_: Exception) { }
        }
    }

    private fun startTicker() {
        stopTicker()
        ticker = object : Runnable {
            override fun run() { refreshCounters(); handler.postDelayed(this, 1000L) }
        }
        handler.postDelayed(ticker!!, 1000L)
    }

    private fun stopTicker() {
        ticker?.let { handler.removeCallbacks(it) }
        ticker = null
    }

    @SuppressLint("SetTextI18n")
    fun refreshCounters() {
        val c = container ?: return
        val ctx = c.context
        val p = ClickerPrefs(ctx)
        val elapsed = p.accumulatedMs +
            if (p.sessionStartMs != 0L) SystemClock.elapsedRealtime() - p.sessionStartMs else 0L
        val t = elapsed / 1000
        counters?.text = String.format(
            "%02d:%02d:%02d   CARTAS %d", t / 3600, (t % 3600) / 60, t % 60, p.sessionPacks
        )
        // Show the log while adjusting, so the diagnostico is one tap away.
        logView?.visibility = if (adjusting) View.VISIBLE else View.GONE
        if (adjusting) {
            logView?.text = CycleLog.tail(6).joinToString("\n")
        }
    }

    fun bumpPacks() { container?.post { refreshCounters() } }

    fun hide() {
        stopTicker()
        adjusting = false
        bonusMode = false
        container?.let { try { wm?.removeView(it) } catch (_: Exception) { } }
        pointers?.let { try { wm?.removeView(it) } catch (_: Exception) { } }
        container = null
        pointers = null
        btnPlay = null; btnEye = null; btnGear = null
        btnSellAll = null; btnSellMulti = null
        counters = null; logView = null; rowModes = null
    }

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()
}
