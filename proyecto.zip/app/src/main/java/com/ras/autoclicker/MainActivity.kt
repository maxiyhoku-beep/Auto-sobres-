package com.ras.autoclicker

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Home screen.
 *
 * The important button here is ACTIVAR PANEL: it checks the two permissions the
 * floating panel needs (accessibility + overlay) and then shows the panel. That
 * button is what was missing in the previous build.
 */
class MainActivity : AppCompatActivity() {

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LanguageManager(newBase).localizedContext())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!getSharedPreferences(LanguageManager.PREFS, MODE_PRIVATE)
                .contains(LanguageManager.KEY_LANG)) {
            startActivity(Intent(this, LanguageActivity::class.java))
        }
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        setContentView(buildUi())
        PanelManager.syncState()
    }

    private fun buildUi(): View {
        val ctx = LanguageManager(this).localizedContext()

        val scroll = ScrollView(ctx).apply {
            setBackgroundColor(0xFF0B0B0B.toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(48, 64, 48, 64)
        }
        scroll.addView(root)

        // ---- Logo ---------------------------------------------------------
        root.addView(ImageView(ctx).apply {
            setImageResource(R.drawable.logo_ras)
            adjustViewBounds = true
            layoutParams = LinearLayout.LayoutParams(dp(180), dp(180))
        })

        root.addView(TextView(ctx).apply {
            text = "RAS// AUTO CLICKER"
            setTextColor(0xFFF5C542.toInt())
            gravity = Gravity.CENTER
            textSize = 24f
            setPadding(0, 18, 0, 6)
        })

        // ---- Status line ---------------------------------------------------
        val status = TextView(ctx).apply {
            gravity = Gravity.CENTER
            textSize = 13f
            setPadding(0, 0, 0, 30)
        }
        fun paintStatus() {
            val acc = ClickerService.instance != null
            val ovl = Settings.canDrawOverlays(this)
            status.text = if (acc && ovl)
                ctx.getString(R.string.ready_to_start)
            else
                ctx.getString(R.string.need_permissions)
            status.setTextColor(if (acc && ovl) 0xFF12B76A.toInt() else 0xFFFF8A65.toInt())
        }
        paintStatus()
        root.addView(status)

        // ---- THE button that was missing ----------------------------------
        root.addView(primary(ctx, ctx.getString(R.string.start_panel)) {
            val acc = ClickerService.instance != null
            val ovl = Settings.canDrawOverlays(this)

            if (!acc) {
                Toast.makeText(this, ctx.getString(R.string.start_service), Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                return@primary
            }
            if (!ovl) {
                Toast.makeText(this, ctx.getString(R.string.overlay_permission), Toast.LENGTH_LONG).show()
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
                return@primary
            }
            PanelManager.show(this)
            Toast.makeText(this, ctx.getString(R.string.panel_opened), Toast.LENGTH_SHORT).show()
        })

        root.addView(primary(ctx, ctx.getString(R.string.screen_capture)) {
            CaptureService.requestCapture(this, REQ_CAPTURE)
        })

        root.addView(primary(ctx, ctx.getString(R.string.channels)) {
            startActivity(Intent(this, ChannelsActivity::class.java))
        })

        root.addView(primary(ctx, ctx.getString(R.string.specific_search)) {
            startActivity(Intent(this, SpecificSearchActivity::class.java))
        })

        // ---- Secondary settings -------------------------------------------
        root.addView(sub(ctx, ctx.getString(R.string.start_service) + ": " +
            if (ClickerService.instance != null) ctx.getString(R.string.granted)
            else ctx.getString(R.string.not_granted)) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        root.addView(sub(ctx, ctx.getString(R.string.overlay_permission) + ": " +
            if (Settings.canDrawOverlays(this)) ctx.getString(R.string.granted)
            else ctx.getString(R.string.not_granted)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })

        root.addView(sub(ctx, ctx.getString(R.string.battery_settings)) { openBatterySettings() })

        root.addView(sub(ctx, "ES / EN") {
            startActivity(Intent(this, LanguageActivity::class.java))
        })

        return scroll
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE) {
            val ok = CaptureService.onResult(this, resultCode, data)
            val svc = ClickerService.instance
            if (ok && svc != null) {
                svc.attachCapture { CaptureService.currentFrame() }
                Toast.makeText(this, getString(R.string.capture_ok), Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, getString(R.string.capture_failed), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun openBatterySettings() {
        val candidates = listOf(
            Intent().setAction("android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS")
                .setData(Uri.parse("package:$packageName")),
            Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:$packageName"))
        )
        for (i in candidates) {
            try { startActivity(i); return } catch (_: Exception) { }
        }
        Toast.makeText(this, "Ajustes > Batería", Toast.LENGTH_LONG).show()
    }

    private fun primary(ctx: Context, label: String, action: () -> Unit): Button =
        Button(ctx).apply {
            text = label
            textSize = 15f
            isAllCaps = false
            setTextColor(0xFF0B0B0B.toInt())
            setBackgroundColor(0xFFF5C542.toInt())
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.bottomMargin = dp(18)
            layoutParams = lp
            setPadding(dp(12), dp(14), dp(12), dp(14))
            setOnClickListener { action() }
        }

    private fun sub(ctx: Context, label: String, action: () -> Unit): Button =
        Button(ctx).apply {
            text = label
            textSize = 12f
            isAllCaps = false
            setTextColor(0xFFF5C542.toInt())
            setBackgroundColor(0xFF161616.toInt())
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.bottomMargin = dp(12)
            layoutParams = lp
            setOnClickListener { action() }
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    companion object {
        const val REQ_CAPTURE = 7701
    }
}
