package com.ras.autoclicker

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * The floating panel, small and rounded.
 *
 *  - idle   : ▶  👁  ⚙  ✕ over a second row with SELL ALL / SELL MULTI
 *  - running: ▶ becomes ⏸ and the mode row collapses away
 *
 * The pointer layer lives in its own window and is added here, so both appear
 * together and the pointers stay above the game.
 */
object PanelManager {

    private var container: LinearLayout? = null
    private var pointers: PointersView? = null
    private var wm: WindowManager? = null

    private var rowModes: LinearLayout? = null
    private var counters: TextView? = null
    private var btnPlay: TextView? = null
    private var btnEye: TextView? = null
    private var btnGear: TextView? = null
    private var btnSellAll: TextView? = null
    private var btnSellMulti: TextView? = null

    private var lpPanel: WindowManager.LayoutParams? = null
    private var lpPointers: WindowManager.LayoutParams? = null

    private val handler = Handler(Looper.getMainLooper())
    private var ticker: Runnable? = null

    /** True while the BONUS dialog is on screen, so its two pointers show. */
    @Volatile var bonusMode = false

    /** True while the user is placing pointers. */
    @Volatile var adjusting = false
        private set

    private val GOLD = 0xFFF5C542.toInt()
    private val DARK = 0xF00B0B0B.toInt()
    private val GREEN = 0xFF12B76A.toInt()
    private val INK = 0xFF0B0B0B.toInt()

    // ------------------------------------------------------------------

    @SuppressLint("InflateParams")
    fun show(context: Context) {
        if (container != null) {
            syncState()
            return
        }
        val ctx = LanguageManager(context).localizedContext()
        wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val type = overlayType()

        // Pointer layer first, so it sits underneath the panel buttons.
        val pv = PointersView(ctx)
        pointers = pv
        lpPointers = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        // ---- Panel shell --------------------------------------------------
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(DARK, 22f, ctx)
            setPadding(dp(ctx, 8), dp(ctx, 6), dp(ctx, 8), dp(ctx, 6))
        }

        counters = TextView(ctx).apply {
            setTextColor(GOLD)
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(ctx, 2), 0, dp(ctx, 6))
        }
        root.addView(counters)

        val rowMain = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        btnPlay = pill(ctx, "\u25B6") {
            val svc = ClickerService.instance
            val p = ClickerPrefs(ctx)
            when {
                svc == null ->
                    Toast.makeText(ctx, ctx.getString(R.string.start_service), Toast.LENGTH_SHORT).show()
                p.panelRunning -> { svc.pauseCycle(); ClickerForegroundService.stop(ctx) }
                else -> {
                    ClickerForegroundService.start(ctx)
                    svc.startCycle()
                    toast(ctx, ctx.getString(R.string.started))
                }
            }
            syncState()
        }
        btnEye = pill(ctx, "\uD83D\uDC41") {
            val p = ClickerPrefs(ctx)
            p.pointersHidden = !p.pointersHidden
            syncState()
        }
        btnGear = pill(ctx, "\u2699") {
            adjusting = !adjusting
            val p = ClickerPrefs(ctx)
            p.pointersHidden = false
            toast(ctx, ctx.getString(if (adjusting) R.string.adjust_hint else R.string.adjust_saved))
            syncState()
        }
        val btnClose = pill(ctx, "\u2715") {
            ClickerService.instance?.stopAndReset()
            ClickerForegroundService.stop(ctx)
            hide()
        }
        rowMain.addView(btnPlay)
        rowMain.addView(btnEye)
        rowMain.addView(btnGear)
        rowMain.addView(btnClose)
        root.addView(rowMain)

        rowModes = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(ctx, 6), 0, 0)
        }
        btnSellAll = pill(ctx, "SA", wide = true) {
            val p = ClickerPrefs(ctx)
            p.sellAll = !p.sellAll
            if (p.sellAll) p.sellMulti = false
            syncState()
        }
        btnSellMulti = pill(ctx, "SM", wide = true) {
            val p = ClickerPrefs(ctx)
            p.sellMulti = !p.sellMulti
            if (p.sellMulti) p.sellAll = false
            syncState()
        }
        rowModes?.addView(btnSellAll)
        rowModes?.addView(btnSellMulti)
        root.addView(rowModes)

        lpPanel = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(ctx, 14)
            y = dp(ctx, 120)
        }
        root.setOnTouchListener(DragListener(wm!!, lpPanel!!))

        try {
            wm?.addView(pv, lpPointers)
            wm?.addView(root, lpPanel)
            container = root
            syncState()
            startTicker()
        } catch (e: Exception) {
            toast(context, ctx.getString(R.string.overlay_permission))
        }
    }

    /** Rounded icon button in the app's gold/black style. */
    private fun pill(ctx: Context, glyph: String, wide: Boolean = false, onClick: () -> Unit): TextView =
        TextView(ctx).apply {
            text = glyph
            textSize = if (wide) 13f else 19f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(INK)
            background = rounded(GOLD, 16f, ctx)
            val w = if (wide) dp(ctx, 58) else dp(ctx, 46)
            val lp = LinearLayout.LayoutParams(w, dp(ctx, 46))
            lp.marginEnd = dp(ctx, 5)
            layoutParams = lp
            setOnClickListener { onClick(); pulse(this) }
        }

    /** Brief gold -> green flash so a tap is visibly registered. */
    private fun pulse(v: TextView) {
        val ctx = v.context
        v.background = rounded(GREEN, 16f, ctx)
        v.postDelayed({ v.background = rounded(GOLD, 16f, ctx) }, 130)
    }

    private fun rounded(color: Int, radiusDp: Float, ctx: Context): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusDp * ctx.resources.displayMetrics.density
            setColor(color)
            setStroke(dp(ctx, 1), 0xFFB8860B.toInt())
        }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun toast(ctx: Context, msg: String) =
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------

    @SuppressLint("SetTextI18n")
    fun syncState() {
        container?.post {
            val ctx = container?.context ?: return@post
            val p = ClickerPrefs(ctx)

            rowModes?.visibility = if (p.panelRunning) View.GONE else View.VISIBLE
            btnPlay?.text = if (p.panelRunning) "\u23F8" else "\u25B6"
            btnGear?.background = rounded(if (adjusting) GREEN else GOLD, 16f, ctx)
            btnEye?.background = rounded(if (p.pointersHidden) 0xFF666666.toInt() else GOLD, 16f, ctx)
            btnSellAll?.background = rounded(if (p.sellAll) GREEN else GOLD, 16f, ctx)
            btnSellMulti?.background = rounded(if (p.sellMulti) GREEN else GOLD, 16f, ctx)

            // Hand the mode down to the pointer layer.
            pointers?.adjusting = adjusting
            pointers?.visiblePointers = !p.pointersHidden
            pointers?.invalidate()
            applyPointerTouchability()

            refreshCounters()
        }
    }

    /**
     * In adjust mode the pointer layer must be able to receive touches; the
     * rest of the time it stays transparent to them so the game keeps working.
     */
    private fun applyPointerTouchability() {
        val v = pointers ?: return
        val lp = lpPointers ?: return
        val flags = if (adjusting)
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        else
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        if (lp.flags != flags) {
            lp.flags = flags
            try { wm?.updateViewLayout(v, lp) } catch (_: Exception) { }
        }
    }

    private fun startTicker() {
        stopTicker()
        ticker = object : Runnable {
            override fun run() { refreshCounters(); handler.postDelayed(this, 1000L) }
        }
        handler.postDelayed(ticker!!, 1000L)
    }

    private fun stopTicker() {
        ticker?.let { handler.removeCallbacks(it) }
        ticker = null
    }

    @SuppressLint("SetTextI18n")
    fun refreshCounters() {
        val c = container ?: return
        val ctx = c.context
        val p = ClickerPrefs(ctx)
        val elapsed = p.accumulatedMs +
            if (p.sessionStartMs != 0L) SystemClock.elapsedRealtime() - p.sessionStartMs else 0L
        val t = elapsed / 1000
        counters?.text = String.format(
            "%02d:%02d:%02d   \uD83D\uDCE6 %d", t / 3600, (t % 3600) / 60, t % 60, p.sessionPacks
        )
    }

    /** Called by the click loop when the packs counter changes. */
    fun bumpPacks() {
        container?.post { refreshCounters() }
    }

    fun hide() {
        stopTicker()
        adjusting = false
        bonusMode = false
        container?.let { try { wm?.removeView(it) } catch (_: Exception) { } }
        pointers?.let { try { wm?.removeView(it) } catch (_: Exception) { } }
        container = null
        pointers = null
        btnPlay = null; btnEye = null; btnGear = null
        btnSellAll = null; btnSellMulti = null; counters = null; rowModes = null
    }

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()
}
