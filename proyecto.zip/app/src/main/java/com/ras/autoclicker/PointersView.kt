package com.ras.autoclicker

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Build
import android.util.AttributeSet
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.abs

/**
 * Draws the tap pointers over the game.
 *
 * Each pointer is a small draggable marker. In ADJUST mode the layer becomes
 * touchable and the user drags every marker onto its real button; the position
 * is saved as a FRACTION of the screen, so it survives any DPI or resolution.
 */
class PointersView(context: Context) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(2f)
        color = 0xFF12B76A.toInt()
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        textSize = dp(11f)
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    /** Which marker is currently being dragged, or -1. */
    private var dragging = -1

    init {
        setWillNotDraw(false)
    }

    /** Reads positions from prefs and repaints. */
    fun syncFromPrefs() {
        val p = ClickerPrefs(context)
        adjustingMode = PanelManager.adjusting
        invisible = p.pointersHidden
        postInvalidate()
    }

    var adjustingMode = false
        private set
    private var invisible = false

    /** Marker descriptors, resolved fresh on every draw so prefs always win. */
    private data class Marker(
        val key: Pair<String, String>,  // prefs X key, prefs Y key
        val short: String,
        var x: Float,
        var y: Float
    )

    private fun markers(): List<Marker> {
        val p = ClickerPrefs(context)
        return listOf(
            Marker("saveAllX" to "saveAllY", "SA", p.saveAllX, p.saveAllY),
            Marker("sellAllX" to "sellAllY", "SL", p.sellAllX, p.sellAllY),
            Marker("sellMultiX" to "sellMultiY", "SM", p.sellMultiX, p.sellMultiY),
            Marker("nextPackX" to "nextPackY", "NP", p.nextPackX, p.nextPackY),
            Marker("bonusLeftX" to "bonusY", "B1", p.bonusLeftX, p.bonusY),
            Marker("bonusRightX" to "bonusY", "B2", p.bonusRightX, p.bonusY)
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!adjustingMode) {
            // While running, show only the arrow cursor look at low opacity.
            if (invisible) return
        } else if (invisible) {
            return
        }

        val w = width.toFloat()
        val h = height.toFloat()
        val r = dp(20f)

        for (m in markers()) {
            val cx = m.x * w
            val cy = m.y * h
            paint.color = if (adjustingMode) 0x99F5C542.toInt() else 0x55F5C542.toInt()
            canvas.drawCircle(cx, cy, r, paint)
            canvas.drawCircle(cx, cy, r, ring)
            canvas.drawText(m.short, cx, cy + dp(4f), label)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!adjustingMode) return false
        val w = width.toFloat()
        val h = height.toFloat()

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                dragging = -1
                markers().forEachIndexed { i, m ->
                    val dx = abs(event.x - m.x * w)
                    val dy = abs(event.y - m.y * h)
                    if (dx < dp(40f) && dy < dp(40f)) dragging = i
                }
                return dragging != -1
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging == -1) return false
                val m = markers()[dragging]
                m.x = (event.x / w).coerceIn(0f, 1f)
                m.y = (event.y / h).coerceIn(0f, 1f)
                save(m)
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> {
                dragging = -1
                return true
            }
        }
        return false
    }

    /** Persists a marker position, keeping the shared bonus Y in sync. */
    private fun save(m: Marker) {
        val p = ClickerPrefs(context)
        when (m.short) {
            "SA" -> { p.saveAllX = m.x; p.saveAllY = m.y }
            "SL" -> { p.sellAllX = m.x; p.sellAllY = m.y }
            "SM" -> { p.sellMultiX = m.x; p.sellMultiY = m.y }
            "NP" -> { p.nextPackX = m.x; p.nextPackY = m.y }
            "B1" -> { p.bonusLeftX = m.x; p.bonusY = m.y }
            "B2" -> { p.bonusRightX = m.x; p.bonusY = m.y }
        }
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density
}
