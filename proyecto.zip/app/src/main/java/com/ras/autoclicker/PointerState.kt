package com.ras.autoclicker

import android.content.Context

/**
 * Shared state so the pointer layer and the panel agree on when pointers are
 * being placed versus running.
 */
object PointerState {

    @Volatile var adjusting: Boolean = false
    @Volatile var visible: Boolean = true

    fun showAll() { visible = true }
    fun hideAll() { visible = false }
}
