package com.ras.autoclicker

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.AttributeSet
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * The pointer layer.
 *
 * Drawn as its own overlay window so it sits ABOVE the game. Two states:
 *  - watching : transparent to touch, just shows where the active pointer is
 *  - adjusting: receives touches so each marker can be dragged into place
 *
 * Only the pointers that are actually in use are shown, which is what the
 * user asked for: no mode -> Save All; SELL ALL -> that one; SELL MULTI ->
 * that one. Next Pack and the two Bonus candidates appear as needed.
 */
class PointersView(context: Context) : View(context) {

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(2.5f)
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        textSize = dp(12f)
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }

    var adjusting = false
    var visiblePointers = true

    private var dragging = -1

    /** A pointer the user can see and (in adjust mode) move. */
    private data class P(val id: String, val tag: String, var x: Float, var y: Float)

    /**
     * Builds the list of pointers that should be on screen right now, read
     * fresh from preferences so the panel's toggles take effect immediately.
     */
    private fun activePointers(): List<P> {
        val p = ClickerPrefs(context)
        val out = ArrayList<P>()

        // Card screen: exactly one of the three, depending on the mode.
        when {
            p.sellAll -> out.add(P("sellAll", "SELL ALL", p.sellAllX, p.sellAllY))
            p.sellMulti -> out.add(P("sellMulti", "SELL DUP", p.sellMultiX, p.sellMultiY))
            else -> out.add(P("saveAll", "SAVE ALL", p.saveAllX, p.saveAllY))
        }
        // Pack screen: the one that advances the cycle.
        out.add(P("nextPack", "NEXT PACK", p.nextPackX, p.nextPackY))

        // Bonus: only while that dialog is on screen.
        if (PanelManager.bonusMode) {
            out.add(P("bonusLeft", "OK ?", p.bonusLeftX, p.bonusY))
            out.add(P("bonusRight", "OK ?", p.bonusRightX, p.bonusY))
        }
        return out
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!adjusting && !visiblePointers) return

        val w = width.toFloat()
        val h = height.toFloat()
        val r = dp(23f)

        for (p in activePointers()) {
            val cx = p.x * w
            val cy = p.y * h

            fill.color = if (adjusting) 0xCCF5C542.toInt() else 0x88F5C542.toInt()
            stroke.color = 0xFF12B76A.toInt()

            canvas.drawCircle(cx, cy, r, fill)
            canvas.drawCircle(cx, cy, r, stroke)
            canvas.drawCircle(cx, cy, dp(3f), stroke)

            // Crosshair so the exact tap point is obvious.
            canvas.drawLine(cx - r, cy, cx + r, cy, stroke)
            canvas.drawLine(cx, cy - r, cx, cy + r, stroke)

            canvas.drawText(p.tag, cx, cy + r + dp(14f), text)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!adjusting) return false
        val w = width.toFloat()
        val h = height.toFloat()
        val list = activePointers()

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                dragging = -1
                list.forEachIndexed { i, p ->
                    val dx = event.x - p.x * w
                    val dy = event.y - p.y * h
                    if (sqrt(dx * dx + dy * dy) < dp(48f)) dragging = i
                }
                return dragging != -1
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging == -1 || dragging >= list.size) return false
                val p = list[dragging]
                p.x = (event.x / w).coerceIn(0f, 1f)
                p.y = (event.y / h).coerceIn(0f, 1f)
                persist(p)
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = -1
                return true
            }
        }
        return false
    }

    /** Saves one pointer position as a fraction of the screen. */
    private fun persist(p: P) {
        val prefs = ClickerPrefs(context)
        when (p.id) {
            "saveAll" -> { prefs.saveAllX = p.x; prefs.saveAllY = p.y }
            "sellAll" -> { prefs.sellAllX = p.x; prefs.sellAllY = p.y }
            "sellMulti" -> { prefs.sellMultiX = p.x; prefs.sellMultiY = p.y }
            "nextPack" -> { prefs.nextPackX = p.x; prefs.nextPackY = p.y }
            "bonusLeft" -> { prefs.bonusLeftX = p.x; prefs.bonusY = p.y }
            "bonusRight" -> { prefs.bonusRightX = p.x; prefs.bonusY = p.y }
        }
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density
}
