package com.ras.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.util.Log
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlin.math.max

/**
 * The tap engine.
 *
 * Fixes over the previous build:
 *
 * 1. realScreenRect(): the tap coordinates are computed against the REAL
 *    display (including the area behind the navigation bar), not against
 *    resources.displayMetrics which can report a smaller box. That mismatch
 *    was putting every tap in the wrong place.
 * 2. startCycle() no longer depends on the service already being connected;
 *    it flips the flag and the watchdog starts the loop on connect.
 * 3. Every step writes to a small log the panel shows, so a failure is
 *    visible instead of silent.
 */
class ClickerService : AccessibilityService() {

    private lateinit var prefs: ClickerPrefs
    private val handler = Handler(Looper.getMainLooper())

    @Volatile private var cycleActive = false
    @Volatile private var lastGestureAt = 0L

    private var detector: ShapeDetector? = null

    private enum class Step { CARD_SCREEN, PACK_SCREEN, BONUS, SKIP }

    override fun onCreate() {
        super.onCreate()
        prefs = ClickerPrefs(this)
        instance = this
        detector = ShapeDetector(this, prefs)
        acquireWakeLock()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        // A fresh connection is exactly when a clicker usually goes mute.
        if (prefs.panelRunning) restartCycle()
        startWatchdog()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        cycleActive = false
        instance = null
        releaseWakeLock()
        super.onDestroy()
    }

    // ------------------------------------------------------------------
    // Entry points used by the panel
    // ------------------------------------------------------------------

    fun startCycle() {
        prefs.panelRunning = true
        if (prefs.sessionStartMs == 0L) prefs.sessionStartMs = SystemClock.elapsedRealtime()
        CycleLog.add("start -> pantalla de cartas")
        restartCycle()
    }

    fun pauseCycle() {
        prefs.panelRunning = false
        if (prefs.sessionStartMs != 0L) {
            prefs.accumulatedMs += SystemClock.elapsedRealtime() - prefs.sessionStartMs
            prefs.sessionStartMs = 0L
        }
        cycleActive = false
        handler.removeCallbacksAndMessages(null)
        CycleLog.add("pausado")
    }

    fun stopAndReset() {
        pauseCycle()
        prefs.resetSession()
        CycleLog.add("detenido y contadores en cero")
    }

    fun attachCapture(provider: () -> android.graphics.Bitmap?) {
        detector?.frameProvider = provider
        CycleLog.add(if (provider() != null) "captura OK" else "captura sin imagen")
    }

    private fun restartCycle() {
        cycleActive = false
        handler.removeCallbacksAndMessages(null)
        if (prefs.panelRunning) {
            cycleActive = true
            handler.postDelayed({ tick(Step.CARD_SCREEN) }, 400L)
        }
    }

    // ------------------------------------------------------------------
    // Watchdog
    // ------------------------------------------------------------------

    private fun startWatchdog() {
        handler.removeCallbacks(watchdog)
        handler.postDelayed(watchdog, WATCHDOG_MS)
    }

    private val watchdog = object : Runnable {
        override fun run() {
            val stale = SystemClock.elapsedRealtime() - lastGestureAt > STALE_MS
            if (prefs.panelRunning && isScreenOn() && !cycleActive) {
                CycleLog.add("watchdog: relanzando ciclo")
                restartCycle()
            } else if (prefs.panelRunning && stale && cycleActive) {
                // The cycle claims to be running but nothing has tapped: re-arm.
                CycleLog.add("watchdog: ciclo trabado, reinicio")
                restartCycle()
            }
            handler.postDelayed(this, WATCHDOG_MS)
        }
    }

    private fun isScreenOn(): Boolean {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isInteractive
    }

    // ------------------------------------------------------------------
    // The cycle
    // ------------------------------------------------------------------

    private fun tick(step: Step) {
        if (!prefs.panelRunning) {
            cycleActive = false
            return
        }
        when (step) {
            Step.BONUS -> handleBonus()
            Step.PACK_SCREEN -> handlePackScreen()
            Step.SKIP -> handleSkip()
            Step.CARD_SCREEN -> handleCardScreen()
        }
    }

    private fun handleCardScreen() {
        val x: Float
        val y: Float
        val which: String
        when {
            prefs.sellAll -> { x = prefs.sellAllX; y = prefs.sellAllY; which = "SELL ALL" }
            prefs.sellMulti -> { x = prefs.sellMultiX; y = prefs.sellMultiY; which = "SELL DUP" }
            else -> { x = prefs.saveAllX; y = prefs.saveAllY; which = "SAVE ALL" }
        }
        CycleLog.add("cartas -> $which  (%.3f, %.3f)".format(x, y))
        tapFraction(x, y) {
            afterTap {
                prefs.sessionPacks = prefs.sessionPacks + 1
                PanelManager.bumpPacks()
                handler.postDelayed({ decideNext() }, 700L)
            }
        }
    }

    private fun handlePackScreen() {
        CycleLog.add("sobre -> NEXT PACK")
        tapFraction(prefs.nextPackX, prefs.nextPackY) {
            afterTap { handler.postDelayed({ tick(Step.SKIP) }, 700L) }
        }
    }

    private fun handleSkip() {
        CycleLog.add("animacion -> SKIP")
        tapFraction(prefs.skipX, prefs.skipY) {
            afterTap { handler.postDelayed({ tick(Step.CARD_SCREEN) }, 700L) }
        }
    }

    /**
     * The BONUS dialog swaps the OK button between the two sides. Tap one,
     * then check whether the dialog went away; if it did not, tap the other.
     */
    private fun handleBonus() {
        val y = prefs.bonusY
        CycleLog.add("bonus -> intento izquierda")
        tapFraction(prefs.bonusLeftX, y) {
            afterTap {
                if (detector?.bonusVisible() == false) {
                    CycleLog.add("bonus -> resuelto con la izquierda")
                    handler.postDelayed({ tick(Step.SKIP) }, 500L)
                } else {
                    CycleLog.add("bonus -> reintento derecha")
                    tapFraction(prefs.bonusRightX, y) {
                        afterTap { handler.postDelayed({ tick(Step.SKIP) }, 500L) }
                    }
                }
            }
        }
    }

    private fun decideNext() {
        if (!prefs.panelRunning) { cycleActive = false; return }
        if (detector?.bonusVisible() == true) {
            CycleLog.add("bonus detectado")
            tick(Step.BONUS)
        } else {
            tick(Step.PACK_SCREEN)
        }
    }

    private fun afterTap(next: () -> Unit) {
        if (!prefs.panelRunning) { cycleActive = false; return }
        handler.postDelayed(next, prefs.intervalMs)
    }

    // ------------------------------------------------------------------
    // Gesture dispatch
    // ------------------------------------------------------------------

    /**
     * The real display box. Using the full display size — not the metrics the
     * service is handed — is what keeps the tap where the pointer is drawn.
     */
    private fun realScreenRect(): Rect {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            wm.currentWindowMetrics.bounds
        } else {
            val d = resources.displayMetrics
            Rect(0, 0, d.widthPixels, d.heightPixels)
        }
    }

    private fun tapFraction(fx: Float, fy: Float, onDone: () -> Unit) {
        val box = realScreenRect()
        val px = (box.left + fx * box.width()).toInt().coerceIn(box.left, box.right - 1)
        val py = (box.top + fy * box.height()).toInt().coerceIn(box.top, box.bottom - 1)

        val path = Path().apply { moveTo(px.toFloat(), py.toFloat()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, TAP_DURATION_MS))
            .build()

        lastGestureAt = SystemClock.elapsedRealtime()

        val accepted = try {
            dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(description: GestureDescription?) {
                    CycleLog.add("toque OK en ($px, $py)")
                    onDone()
                }
                override fun onCancelled(description: GestureDescription?) {
                    CycleLog.add("toque CANCELADO en ($px, $py)")
                    onDone()
                }
            }, null)
        } catch (e: Exception) {
            CycleLog.add("toque fallo: ${e.javaClass.simpleName}")
            false
        }

        if (!accepted) {
            CycleLog.add("toque RECHAZADO en ($px, $py)")
            handler.postDelayed(onDone, 60L)
        }
    }

    // ------------------------------------------------------------------
    // Wake lock
    // ------------------------------------------------------------------

    private var wakeLock: PowerManager.WakeLock? = null

    private fun acquireWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RAS::ClickerLock").apply {
            setReferenceCounted(false)
            try { acquire() } catch (_: Exception) { }
        }
    }

    private fun releaseWakeLock() {
        try { wakeLock?.takeIf { it.isHeld }?.release() } catch (_: Exception) { }
        wakeLock = null
    }

    companion object {
        private const val WATCHDOG_MS = 5_000L
        private const val STALE_MS = 15_000L
        private const val TAP_DURATION_MS = 40L

        @Volatile var instance: ClickerService? = null
            private set
    }
}
